import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './components/Navbar';
import './css/Header.css';
import vago from './img/vago.jpg';

function Header() {
  return (
    <header>
      <nav className="main-nav">
        <div className="dropdown">
          <div className="dropdown-content">
            <Navbar />
          </div>
        </div>
        <div className="logo-name">
          <Link to="/">
            <img src={vago} />
          </Link>
          <h1>Prochainement</h1>
        </div>
        <div className="auth-buttons">
          <Link to="/login">
            <button>Se connecter</button>
          </Link>
          <Link to="/register">
            <button className="join-button active">↗️ REJOINDRE </button>
          </Link>
        </div>
      </nav>
    </header>
  );
}

export default Header;
