import React, { useState, onClick } from "react";
import { Link } from 'react-router-dom';
import "../css/LoginPage.css"; // Import de la feuille de style



function LoginPage() {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [rememberMe, setRememberMe] = useState(false); // Etat de la checkbox

    const handleUsernameChange = (event) => {
        setUsername(event.target.value);
    };

    const handlePasswordChange = (event) => {
        setPassword(event.target.value);
    };

    const handleRememberMeChange = (event) => {
        setRememberMe(event.target.checked); // Changement de l'état de la checkbox
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log("Username: ", username);
        console.log("Password: ", password);
        console.log("Remember me: ", rememberMe); // Affichage de l'état de la checkbox
    };

    return (
        <div className="login-page">
            <h2>Connecte toi à ton compte</h2>
            <form className="login-form" onSubmit={handleSubmit}>
                <label htmlFor="username">Email :</label>
                <div >
                    <input className="login-form-input box"
                        type="text"
                        id="username"
                        value={username}
                        onChange={handleUsernameChange}
                        placeholder="Adresse mail ..."
                    />
                </div>
                <label htmlFor="password">Mot de passe :</label>
                <div>
                    <input
                        className="login-form-input box"
                        type="password"
                        id="password"
                        value={password}
                        onChange={handlePasswordChange}
                        placeholder="Mot de passe ..."
                    />
                </div>

                <button type="submit">Connexion</button>
                <button type="submit"><i class="fa fa-google"></i>Se connecter avec Google</button>



                <div>
                    <label htmlFor="remember-me" className="remember-me-label">
                    </label>
                    <div className="remember-me-container">
                        <input
                            type="checkbox"
                            id="remember-me"
                            className="checkbox-custom"
                            checked={rememberMe}
                            onChange={handleRememberMeChange}
                        />
                        <label htmlFor="remember-me" className="remember-me-label">
                            Se souvenir de moi
                        </label>
                    </div>
                    <div className="join-container">
                        <p className="clique-ici">Pas encore de compte ?</p>
                        <Link to="/register">
            <button className="join-button active">Rejoindre</button>
          </Link>
                    </div>


                </div>

            </form>

        </div>
    );
}

export default LoginPage;